cubeVerts=nil
cubeColors=nil
rotate = { 0.0,0,0}
rotSpeed = 5.0;
eye={ 0,3.0,17.3}
projection = { 45.0,1.0,-0.1,-200.0}
function init()
end
