#include "Timer.h"

//struct timeval timer::tv;
//int64_t Timer::cached = 0;
